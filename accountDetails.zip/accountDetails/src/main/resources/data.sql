INSERT INTO account (account_number, account_holder_name, currency, branch)
VALUES ('1234567890', 'John Doe', 'USD', 'New York');

INSERT INTO account (account_number, account_holder_name, currency, branch)
VALUES ('9876543210', 'Jane Smith', 'EUR', 'Berlin');
